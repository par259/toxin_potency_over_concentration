# Core tidyverse and data manipulation
library(tidyverse)    # includes ggplot2, dplyr, tidyr, readr, stringr, etc.
library(janitor)      # for clean_names()
library(readxl)       # to read Excel data

# Phylogenetic analysis
library(ape)          # for read.tree(), phylo objects, and name.check()
library(phytools)     # for tree manipulation and plotting
library(phylolm)      # for phylogenetic linear models
library(geiger)       # for comparative methods
library(nlme)         # for linear and nonlinear mixed effects models
library(expm)         # matrix exponential functions
library(vegan)
# Visualization helpers
library(ggpubr)       # for ggplot enhancements
library(patchwork)    # for plot combinations
library(scales)       # for controlling scales and formatting
library(viridis)      # for color scales
library(ggrepel)
# Statistical modeling
library(pscl)         # for zero-inflated models (zeroinfl)
library(MASS)         # for various statistical functions
library(rstatix)      # for tidy statistical tests
library(tibble)
library(stringr)


cbbPalettem <- c( "#56B4E9", "#E69F00", "#CC79A7","#808080")
`%nin%` = Negate(`%in%`)

