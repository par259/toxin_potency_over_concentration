# Core data wrangling and plotting
library(tidyverse)    # includes dplyr, ggplot2, tidyr, readr, tibble, etc.
library(janitor)      # for clean_names()
library(readxl)       # for read_xlsx()

# Useful for reshaping and cleaning
library(stringr)
library(broom)

# Visualization-specific
library(patchwork)    # for combining plots (if used)
library(ggpubr)       # used for stat_cor, etc.
library(scales)       # for controlling scales if needed
# Custom palettes
colorBlindBlack8  <- c("#E69F00", "#56B4E9", "#009E73", 
                       "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
library(ggrepel)
cbbPalettex <- c("#D55E00", "#CC79A7")

# Custom operator
`%nin%` <- Negate(`%in%`)
