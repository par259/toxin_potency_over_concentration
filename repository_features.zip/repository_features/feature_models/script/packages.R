# Core tidyverse packages
install.packages("tidyverse")     # includes dplyr, ggplot2, readr, tidyr, etc.
install.packages("janitor")       # for clean_names()
install.packages("readxl")        # for reading Excel files

# Data manipulation and summary
install.packages("broom")         # for tidying model outputs (if used later)
install.packages("stringr")       # for string manipulation

# Visualization enhancements
install.packages("ggplot2")       # already included in tidyverse
install.packages("patchwork")     # if you plan to combine plots
install.packages("ggpubr")        # if using `stat_cor()` or similar later

# Optional but used
install.packages("scales")        # for axis scaling (if customized)
