# Core tidy data manipulation
install.packages("tidyverse")     # includes ggplot2, dplyr, readr, tidyr, stringr, etc.
install.packages("janitor")       # for clean_names()
install.packages("readxl")        # for read_xlsx()

# Phylogenetic analysis
install.packages(c("ape", "phytools", "phylolm", "geiger", "nlme", "expm"))

# Visualization enhancements
install.packages(c("ggpubr", "patchwork", "viridis", "scales", "car"))

# Statistical modeling and utilities
install.packages(c("pscl", "MASS"))

install.packages("vegan")