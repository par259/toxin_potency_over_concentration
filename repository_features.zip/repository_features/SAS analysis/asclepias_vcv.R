# Transform Asclepias phylogenetic tree in a variance-covariance matrix

#install.packages("caper")
library(caper)

atree <- read.tree("asclepias_tree_cleaned.tre")

vcvasclepias <- as.data.frame(vcv.phylo(atree))

write.csv(vcvasclepias, "vcvasclepias.csv")
